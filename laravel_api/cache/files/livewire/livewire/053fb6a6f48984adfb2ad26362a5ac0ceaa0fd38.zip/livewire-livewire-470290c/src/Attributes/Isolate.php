<?php

namespace Livewire\Attributes;

use Livewire\Features\SupportIsolating\BaseIsolate;

#[\Attribute]
class Isolate extends BaseIsolate
{
    //
}
